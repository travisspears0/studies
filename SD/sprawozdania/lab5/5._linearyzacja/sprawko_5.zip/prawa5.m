
function w=prawa(t,x)
  x1=x(1);
  w(1)=x(2);
  w(2)=2*x1-x(2);
end