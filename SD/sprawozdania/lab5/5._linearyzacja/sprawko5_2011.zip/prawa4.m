function w=prawa14(t,x)
  w(1)=x(2);
  w(2)=-2*x(1)-3*x(1)^2-x(2);
end